import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const prospects = sqliteTable('prospects', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), url: text('url').notNull(),
  payload: text('payload').notNull(), revision: integer('revision').notNull().default(1), updatedAt: text('updated_at').notNull(),
}, (t) => [index('prospects_owner_idx').on(t.ownerId), uniqueIndex('prospects_owner_url_idx').on(t.ownerId, t.url)]);
