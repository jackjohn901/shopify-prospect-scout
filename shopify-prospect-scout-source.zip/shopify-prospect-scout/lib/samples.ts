import type { Prospect } from './prospect';
export function samples(): Prospect[] {
  const now = new Date().toISOString();
  return [
    { name:'Forma & Field', domain:'forma-field.example', country:'United States', platform:'Shopify', category:'Product & cart', observation:'On the linen product page, selecting the medium size leaves the Add to cart button disabled at a 390px viewport.', kind:'Visible issue', severity:'High', status:'Shortlisted', intent:true },
    { name:'Northline Supply', domain:'northline.example', country:'Canada', platform:'Shopify', category:'Navigation & links', observation:'The footer size-guide link returns a 404 page when opened from the collection page.', kind:'Visible issue', severity:'Medium', status:'Researching', intent:false },
    { name:'Sunday Objects', domain:'sunday-objects.example', country:'United Kingdom', platform:'Webflow', category:'Mobile experience', observation:'At a 375px viewport the enquiry form submit button sits outside the visible page width.', kind:'Visible issue', severity:'High', status:'Researching', intent:false },
    { name:'Moss Studio', domain:'moss-studio.example', country:'Australia', platform:'Shopify', category:'Theme & layout', observation:'We are considering getting help with the overlapping product titles in our new Shopify theme.', kind:'Considering help', severity:'Medium', status:'Researching', intent:false },
    { name:'Atelier Cove', domain:'atelier-cove.example', country:'United States', platform:'WordPress', category:'Website rebuild', observation:'The services navigation item opens an empty page with only a heading and no enquiry link.', kind:'Visible issue', severity:'Low', status:'Researching', intent:false },
  ].map((x,i) => ({id:`sample-${i}`,name:x.name,url:`https://${x.domain}`,country:x.country,platform:x.platform,status:x.status,notes:'Fictional example for exploring Scout. These are not real prospects or verified findings.',createdAt:now,updatedAt:now,revision:0,
    evidence:[{id:`e-${i}`,observation:x.observation,sourceUrl:`https://${x.domain}/pages/research-example`,category:x.category,severity:x.severity,kind:x.kind,verified:true,observedAt:now},...(x.intent?[{id:'intent',observation:'Looking for a Shopify developer to help fix our size selector. Please share your approach.',sourceUrl:`https://${x.domain}/pages/public-request`,category:x.category,severity:'High',kind:'Explicit help request',verified:true,observedAt:now}]:[])],
    contacts:i===2?[]:[{id:`c-${i}`,type:'Email',value:`hello@${x.domain}`,sourceUrl:`https://${x.domain}/pages/contact`,observedAt:now}]
  } as Prospect));
}
