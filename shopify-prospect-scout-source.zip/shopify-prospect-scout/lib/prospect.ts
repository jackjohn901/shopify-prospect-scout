import { z } from 'zod';
export const categories = ['Theme & layout', 'Product & cart', 'Navigation & links', 'Mobile experience', 'Performance', 'Apps & integrations', 'Website rebuild', 'Other'] as const;
export const platforms = ['Shopify', 'WordPress', 'Wix', 'Webflow', 'Custom / other', 'Unconfirmed'] as const;
export const statuses = ['Researching', 'Shortlisted', 'Contacted', 'Archived', 'Do not contact'] as const;
export const channelTypes = ['Email', 'Phone', 'Contact form', 'LinkedIn', 'Instagram', 'Other public URL'] as const;
const safeUrl = z.string().trim().max(2048).url().refine(v => ['http:', 'https:'].includes(new URL(v).protocol), 'Use a public http or https URL');
const timestamp = z.string().datetime().refine(v => Date.parse(v) <= Date.now() + 60000, 'Date cannot be in the future');
export const evidenceSchema = z.object({
  id: z.string().min(1).max(80), observation: z.string().trim().min(12).max(2000), sourceUrl: safeUrl,
  category: z.enum(categories), severity: z.enum(['Low', 'Medium', 'High']),
  kind: z.enum(['Visible issue', 'Considering help', 'Explicit help request']), verified: z.boolean(), observedAt: timestamp,
});
export const contactSchema = z.object({
  id: z.string().min(1).max(80), type: z.enum(channelTypes), value: z.string().trim().min(3).max(2048), sourceUrl: safeUrl, observedAt: timestamp,
}).superRefine((v, ctx) => {
  const valid = v.type === 'Email' ? z.string().email().safeParse(v.value).success : v.type === 'Phone' ? /^[+\d()\s.-]{6,40}$/.test(v.value) : safeUrl.safeParse(v.value).success;
  if (!valid) ctx.addIssue({code: 'custom', path:['value'], message: 'Enter a valid email, phone number, or public URL for this channel'});
});
export const prospectSchema = z.object({
  id: z.string().min(1).max(80), name: z.string().trim().min(2).max(120), url: safeUrl,
  country: z.string().trim().min(2).max(80), platform: z.enum(platforms), status: z.enum(statuses), notes: z.string().max(5000),
  evidence: z.array(evidenceSchema).max(100), contacts: z.array(contactSchema).max(50),
  createdAt: timestamp, updatedAt: timestamp, revision: z.number().int().nonnegative(),
});
export type Evidence = z.infer<typeof evidenceSchema>;
export type Contact = z.infer<typeof contactSchema>;
export type Prospect = z.infer<typeof prospectSchema>;
export function canonicalUrl(input: string) {
  const u = new URL(input.includes('://') ? input : `https://${input}`);
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Use an http or https website URL');
  u.hash = ''; u.hostname = u.hostname.toLowerCase();
  return u.toString().replace(/\/$/, '');
}
export function isFresh(e: Evidence | Contact, now = Date.now()) {
  const age = now - Date.parse(e.observedAt);
  return Number.isFinite(age) && age >= -60000 && age <= 30 * 86400000;
}
export function verifiedEvidence(p: Prospect, now = Date.now()) { return p.evidence.filter(e => e.verified && isFresh(e, now)); }
export function score(p: Prospect, now = Date.now()) {
  const ev = verifiedEvidence(p, now), issues = ev.filter(e => e.kind === 'Visible issue');
  const intent = ev.some(e => e.kind === 'Explicit help request') ? 100 : ev.some(e => e.kind === 'Considering help') ? 60 : 0;
  const impact = Math.max(0, ...issues.map(e => ({Low:20, Medium:45, High:70})[e.severity]));
  const contactable = p.contacts.some(c => isFresh(c, now));
  return { intent, priority: Math.min(100, impact + Math.round(intent * .3)), issues: issues.length, verified: ev.length, contactable,
    ready: ev.length > 0 && contactable && !['Archived', 'Do not contact', 'Contacted'].includes(p.status) };
}
export function outreach(p: Prospect, now = Date.now()) {
  if (p.status === 'Do not contact') return null;
  const ev = verifiedEvidence(p, now); if (!ev.length) return null;
  const e = [...ev].sort((a,b) => (b.kind !== 'Visible issue' ? 10 : 0) - (a.kind !== 'Visible issue' ? 10 : 0) || ({Low:1,Medium:2,High:3})[b.severity] - ({Low:1,Medium:2,High:3})[a.severity])[0];
  const tasks: Record<string,string> = {
    'Theme & layout':'review the affected layout and fix the underlying theme behavior', 'Product & cart':'trace the product-to-cart flow and address the reproducible issue',
    'Navigation & links':'trace the broken navigation path and repair the affected links', 'Mobile experience':'reproduce the mobile behavior and fix the affected layout or interaction',
    'Performance':'measure the affected page and investigate the source of the slowdown', 'Apps & integrations':'trace the integration behavior and identify a targeted fix',
    'Website rebuild':'review the current site and scope the specific changes it needs', 'Other':'reproduce the behavior and scope a focused fix',
  };
  const opening = e.kind === 'Visible issue' ? `While reviewing ${p.name}, I recorded this on your public page: “${e.observation}”` : `I saw this public note about ${p.name}: “${e.observation}”`;
  const text = `${opening}\n\nI can ${tasks[e.category]}. I’d first confirm the behavior and share a clear scope so you can assess the next step.\n\nWould a short breakdown of what I’d check be useful?\n\nEmmanuel`;
  return { subject: `${e.category} on ${p.name}`, text, evidence: e, angle: `${e.category}: lead with the recorded observation, then offer a focused diagnosis and scope.` };
}
