import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { prospectSchema, canonicalUrl } from '../../../lib/prospect';
export const dynamic = 'force-dynamic';
const reply = (data: unknown, status = 200) => Response.json(data, {status, headers:{'Cache-Control':'no-store'}});
async function identity(req: Request) {
  const origin = req.headers.get('origin');
  if (origin && origin !== new URL(req.url).origin) return null;
  return getChatGPTUser();
}
export async function GET(req: Request) {
  const user = await identity(req); if (!user) return reply({error:'Sign in to open your private workspace.'},401);
  try {
    const rows = await env.DB!.prepare('SELECT payload, revision FROM prospects WHERE owner_id = ? ORDER BY updated_at DESC LIMIT 1000').bind(user.userId).all<{payload:string,revision:number}>();
    return reply({prospects: rows.results.map(r => ({...JSON.parse(r.payload), revision:r.revision}))});
  } catch { return reply({error:'Your workspace could not be loaded. Please retry.'},503); }
}
export async function POST(req: Request) {
  const user = await identity(req); if (!user) return reply({error:'Sign in to save to your private workspace.'},401);
  if (Number(req.headers.get('content-length') || 0) > 400000) return reply({error:'Record is too large.'},413);
  try {
    const raw = await req.text(); if (raw.length > 400000) return reply({error:'Record is too large.'},413);
    const parsed = prospectSchema.safeParse(JSON.parse(raw));
    if (!parsed.success) return reply({error:parsed.error.issues.map(x => x.message).join('. ')},400);
    const p = parsed.data; p.url = canonicalUrl(p.url);
    const duplicate = await env.DB!.prepare('SELECT id FROM prospects WHERE owner_id = ? AND url = ? AND id != ?').bind(user.userId,p.url,p.id).first();
    if (duplicate) return reply({error:'This prospect URL is already in your workspace.'},409);
    const existing = await env.DB!.prepare('SELECT owner_id, revision FROM prospects WHERE id = ?').bind(p.id).first<{owner_id:string,revision:number}>();
    if (existing && existing.owner_id !== user.userId) return reply({error:'Record unavailable.'},404);
    if (existing && existing.revision !== p.revision) return reply({error:'This record changed in another tab. Refresh your workspace before editing.'},409);
    p.updatedAt = new Date().toISOString(); p.revision = (existing?.revision || 0) + 1;
    if (existing) {
      const result = await env.DB!.prepare('UPDATE prospects SET url = ?, payload = ?, revision = ?, updated_at = ? WHERE id = ? AND owner_id = ? AND revision = ?').bind(p.url, JSON.stringify(p), p.revision, p.updatedAt, p.id, user.userId, existing.revision).run();
      if (!result.meta.changes) return reply({error:'Record changed. Refresh and try again.'},409);
    } else await env.DB!.prepare('INSERT INTO prospects (id, owner_id, url, payload, revision, updated_at) VALUES (?, ?, ?, ?, ?, ?)').bind(p.id,user.userId,p.url,JSON.stringify(p),p.revision,p.updatedAt).run();
    return reply({prospect:p});
  } catch { return reply({error:'Save failed. Check your inputs and try again.'},400); }
}
export async function DELETE(req: Request) {
  const user = await identity(req); if (!user) return reply({error:'Sign in to edit your workspace.'},401);
  const id = new URL(req.url).searchParams.get('id'); if (!id) return reply({error:'Missing record ID.'},400);
  await env.DB!.prepare('DELETE FROM prospects WHERE id = ? AND owner_id = ?').bind(id,user.userId).run(); return reply({ok:true});
}
