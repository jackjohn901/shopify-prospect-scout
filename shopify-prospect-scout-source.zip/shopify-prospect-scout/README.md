# Scout

An owner-private Shopify and website prospect research workspace built with Vinext and Cloudflare D1 on Sites.

Country input opens a discovery desk with targeted public research links. URL input opens a prospect record. Research is manual and every observation carries a source, observation date, category, impact assessment, and explicit verification flag. No scraping, website scanning, messaging or third-party AI service is connected.

Real records persist in D1 under the signed-in Sites user ID. Every API operation checks identity and owner scope. The platform provides owner-only site access. Sample mode uses clearly labeled fictional .example businesses in temporary memory and never seeds the real database.

Buyer intent is separate from visible problems: verified explicit requests score 100, considering-help statements score 60, and visible defects alone score 0. Only evidence from the past 30 days qualifies. Priority adds the highest issue impact (20/45/70) to 30% of intent, capped at 100. Readiness requires fresh verified evidence and a public channel, and excludes contacted, archived or suppressed prospects. Outreach uses only one qualifying source observation, includes its source link for review, and never sends anything.

## Validation

- `node --experimental-strip-types --test tests/scoring.test.mjs`: evidence gating, expiry, future-date rejection, intent separation, suppression, unsafe URLs and draft grounding.
- `node --test tests/api.test.mjs`: API handlers against real in-memory SQLite using generated migrations; mocked Sites identity and D1 adapter only. Tests cover save/reload/update, owner isolation, duplicate URLs, stale edit revisions, cross-origin writes, malformed input, and deletion.
- `node node_modules/typescript/bin/tsc --noEmit`
- Build with the Sites plugin's `scripts/build-site.mjs`.

Browser QA covers the desktop discovery desk, country filtering, creating a sample prospect, adding evidence, adding a sourced public channel, detail navigation, generated drafts, and do-not-contact suppression. Managed preview lacks signed-in identity, so authenticated persistence is verified by the API tests; hosted authentication is supplied by Sites. Responsive CSS is included; no separate mobile viewport QA was available.
