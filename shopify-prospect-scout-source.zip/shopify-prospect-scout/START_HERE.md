# Shopify Prospect Scout — source package

This ZIP contains the complete source for your private prospect workspace, including the UI, database migrations, dependency lockfile and tests. No prospect records, credentials, installed dependencies, Git history or local runtime files are included.

## Open in Codex / OpenCode
1. Extract the ZIP.
2. Open the shopify-prospect-scout folder.
3. Ask the coding agent to read README.md and preserve the existing Sites project identity in .openai/hosting.json.

## Run locally
Use Node.js 22.13 or newer. From the extracted project folder:

```sh
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm build
```

Apply the database migrations once, in order:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_chilly_deathstrike.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_green_starbolt.sql
pnpm dev
```

Open http://localhost:5173. On portable local development, visit /signin-with-chatgpt?return_to=/ to use the starter's local test identity. The hosted site uses Sites-owned authentication and the owner's private access policy. A generic static host alone will not provide its authentication or D1 database.

## Existing deployment
https://shopify-prospect-scout-emmanuel.ebukajohnking276.chatgpt.site

## Validation
Ten automated tests, TypeScript checking, production build, and desktop workflow QA passed for the supplied version. See README.md for test commands and details.
